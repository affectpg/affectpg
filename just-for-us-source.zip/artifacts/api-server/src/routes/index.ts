import { Router, type IRouter } from "express";
import healthRouter from "./health";
import categoriesRouter from "./categories";
import threadsRouter from "./threads";
import repliesRouter from "./replies";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/categories", categoriesRouter);
router.use("/threads", threadsRouter);
router.use("/threads/:id/replies", repliesRouter);
router.use("/stats", statsRouter);

export default router;
